# Cadastro Seguro de Usuários – Segurança da Informação

Projeto simples que demonstra como proteger senhas de usuários com `bcrypt`, usando Python e SQLite.

## Funcionalidades

- Cadastro de usuários com hash seguro de senha
- Armazenamento em banco SQLite
- Evita e-mails duplicados

## Como rodar

1. Instale a biblioteca:
2. Execute:
